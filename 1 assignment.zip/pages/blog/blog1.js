const blog1 = () => {
  return (
    <>
      <h1>my blog 1 content thapa</h1>
    </>
  );
};

export default blog1;
