"use strict";
(() => {
var exports = {};
exports.id = 195;
exports.ids = [195];
exports.modules = {

/***/ 963:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_blog),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/Navbar.js
var Navbar = __webpack_require__(10);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(664);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(675);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
;// CONCATENATED MODULE: external "react-icons/ri"
const ri_namespaceObject = require("react-icons/ri");
;// CONCATENATED MODULE: ./pages/blog/index.js






const getStaticProps = async ()=>{
    // const data4 = await res.json();
    const res = await fetch("https://jsonplaceholder.typicode.com/comments");
    const data = await res.json();
    const res2 = await fetch("https://randomuser.me/api/?results=50");
    const data2 = await res2.json();
    const data3 = data2.results;
    //const [query, setQuery] = useState("");
    return {
        props: {
            data,
            data2,
            data3
        }
    };
};
const blog = ({ data , data2 , data3  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Navbar/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "ssr-styles3",
                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                    type: "text",
                    className: "search_boxx",
                    placeholder: "search"
                })
            }),
            data.slice(0, 5).map((curElem, i)=>{
                console.log(data3[i]);
                //const[count,setCount]=useState(0);
                const isEvenOdd = (count)=>{
                    return count % 2 === 0;
                };
                const deleteComment = (elem)=>{
                    const req = fetch(`https://jsonplaceholder.typicode.com/posts/${elem}`, {
                        method: 'DELETE'
                    });
                    //const newData = req.json();
                    //const data4 = req.json();
                    console.log(elem);
                    alert("Deleted Record Successfully ");
                };
                return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: isEvenOdd(curElem.id) ? "even_css ssr-styles" : "odd_css ssr-styles",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "imgclass_main",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    src: data3[i].picture.large,
                                    className: "imgclass",
                                    width: 30,
                                    height: 30
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: data3[i].name.first
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(ri_namespaceObject.RiDeleteBinLine, {
                                    className: "delete_icon",
                                    onClick: ()=>deleteComment(curElem.id)
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "comment",
                            children: curElem.body
                        })
                    ]
                }, curElem.id));
            })
        ]
    }));
};
/* harmony default export */ const pages_blog = (blog);


/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 28:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 14:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 20:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 52:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 422:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,664,675,233], () => (__webpack_exec__(963)));
module.exports = __webpack_exports__;

})();