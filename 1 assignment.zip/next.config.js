module.exports = {
  reactStrictMode: true,
  images: {
     domains: ['randomuser.me'],
      // remotePatterns:[{
      //     protocol:'https',
      //     hostname: "randomuser.me",
      //     port: '',
      //     pathname: '/api/portraits/**',
      // },
      // {
      //     protocol:"https",
      //     hostname: "*.me",
      // }]
    // protocol: 'https',

    //

  },
};
